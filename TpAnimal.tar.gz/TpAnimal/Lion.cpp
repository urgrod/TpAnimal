#include "Lion.h"

char Lion::getLettre(){
		return lettre;
}